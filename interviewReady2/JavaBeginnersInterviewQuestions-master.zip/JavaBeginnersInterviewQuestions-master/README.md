# JavaBeginnersInterviewQuestions
This is a git repository for sample code for Udemy course:  "Get your Java dream job! Beginners interview preparation"

I wish you a good luck in the course!

Yuval Ishay,
Computrade
