package inheritance.end;


public interface ColorI extends Transparency {
	void fill();
	void setCode(String code); 
}
