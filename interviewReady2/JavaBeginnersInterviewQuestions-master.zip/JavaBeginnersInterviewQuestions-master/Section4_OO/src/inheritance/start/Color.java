package inheritance.start;

public class Color{
	
	public Color(){
		System.out.println("Printed from Color constructor" );
	}
	
	public void fill() {
		System.out.println("Inside Color::fill() method.");
	}
}
