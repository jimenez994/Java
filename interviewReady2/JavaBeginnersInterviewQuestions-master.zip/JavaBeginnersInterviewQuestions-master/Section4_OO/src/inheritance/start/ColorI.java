package inheritance.start;

public interface ColorI extends Transparency {
	
	void fill();
	void setCode(String code); 

}
