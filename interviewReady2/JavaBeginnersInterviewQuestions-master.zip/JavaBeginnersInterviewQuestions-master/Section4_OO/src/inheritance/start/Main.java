package inheritance.start;

public class Main {
	
	public static void main(String [] args){
		
		Color color = new Color();
		color.fill();
		
		Color blue = new Blue();
		blue.fill();
	
		Color green = new Green();
		green.fill();
	
		Color red = new Red();
		red.fill();
		
	}

}
