package extra;

public class Bicycle {
    public void ride() {
        System.out.println("Riding a bicycle ..."); 
    }
}

