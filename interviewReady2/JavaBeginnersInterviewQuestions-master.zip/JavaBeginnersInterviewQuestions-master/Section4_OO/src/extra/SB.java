package extra;

import java.util.*;

public class SB {
    public static void main(String[] args) {
        StringBuffer s = new StringBuffer();
        s.append(3);
        System.out.println(s.toString());

	String x = "foobar";
	System.out.println(x.indexOf("cat"));
    }
}
