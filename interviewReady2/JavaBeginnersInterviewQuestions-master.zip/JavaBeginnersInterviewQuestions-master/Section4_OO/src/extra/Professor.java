package extra;

public class Professor extends Person { 
    private String name;

    public Professor(String n) {
        name = n;
    }

    public String toString() {
	return name;
    }
}


