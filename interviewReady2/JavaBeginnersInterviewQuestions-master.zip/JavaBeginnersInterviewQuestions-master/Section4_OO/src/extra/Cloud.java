package extra;

public class Cloud {
    public void paint() {
        System.out.println("Painting a cloud ..."); 
    }
}

