package extra;

public class Pineapple {
    public void eat() {
        System.out.println("Eating a pineapple ..."); 
    }
}

