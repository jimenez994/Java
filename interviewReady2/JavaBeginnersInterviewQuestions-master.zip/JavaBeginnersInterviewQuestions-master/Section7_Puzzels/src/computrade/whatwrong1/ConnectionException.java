package computrade.whatwrong1;

@SuppressWarnings("serial")
public class ConnectionException extends RuntimeException{

	ConnectionException(){
		super();
	}
	
	ConnectionException(String message){
		super(message);
	}
	
	
	
}
