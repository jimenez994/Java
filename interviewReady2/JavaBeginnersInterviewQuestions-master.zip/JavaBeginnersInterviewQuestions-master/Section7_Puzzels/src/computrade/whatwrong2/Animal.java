package computrade.whatwrong2;

public class Animal {
	
	public Animal(){
		System.out.println("Animal Constructor.");
		doSomething();
		
	}
	
	public void doSomething() {
        System.out.println("Animal do something");
    }

}
