package computrade.whatwrong2;

public class Person {
	
	
	Person(Dog dog){
		
		System.out.println("This is the person dog:" + dog);
	}

}
