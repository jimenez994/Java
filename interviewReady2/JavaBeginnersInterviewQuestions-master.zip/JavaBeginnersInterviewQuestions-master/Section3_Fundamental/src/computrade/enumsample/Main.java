package computrade.enumsample;

public class Main {

	
public static void main(String [] args){
		
	Deck3 deck = new Deck3();
	deck.printall();
	
	}

}
