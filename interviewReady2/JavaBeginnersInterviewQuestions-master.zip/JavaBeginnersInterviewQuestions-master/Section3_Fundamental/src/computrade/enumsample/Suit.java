package computrade.enumsample;

public enum Suit {
 
		   DIAMONDS, 
		   CLUBS, 
		   HEARTS, 
		   SPADES 
		
}
