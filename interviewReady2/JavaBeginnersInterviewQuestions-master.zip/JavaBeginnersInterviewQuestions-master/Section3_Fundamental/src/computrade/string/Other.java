package computrade.string;

public class Other {

		static String stringFromOtherClass = "myTestString"; 
		
}
