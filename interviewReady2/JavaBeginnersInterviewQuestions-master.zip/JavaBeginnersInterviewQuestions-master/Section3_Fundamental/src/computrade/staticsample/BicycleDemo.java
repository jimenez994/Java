package computrade.staticsample;

public class BicycleDemo {
	public static void main(String[] args) {
		 
        // Create two different 
        // Bicycle objects
        Bicycle bike1 = new Bicycle(50,10,2);
        Bicycle bike2 = new Bicycle(100,20,4);
 
       
        System.out.println(bike1);
        System.out.println(bike2);
    }
}
