package computrade.main;

public class Main {
	

	// main must be public & static & void/
	// method name must be main ( can be changed by configuration )
	// arguments must be an array of Strings.
	// final and synchronized can be added to the function.
	public static final synchronized void main(String... args) {

		Main myMain = new Main();
		//return 0;
	}

}
