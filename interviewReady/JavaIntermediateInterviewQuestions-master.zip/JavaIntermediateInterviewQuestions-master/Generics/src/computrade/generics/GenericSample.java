package computrade.generics;

public class GenericSample {

}
