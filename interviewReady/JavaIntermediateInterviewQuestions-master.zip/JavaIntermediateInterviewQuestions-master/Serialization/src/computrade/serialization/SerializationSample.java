package computrade.serialization;

public class SerializationSample {

}
