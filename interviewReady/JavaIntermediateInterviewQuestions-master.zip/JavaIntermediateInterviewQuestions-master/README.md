# Middle level Interview preparation

This is a git repository with sample code for Udemy course: "Get your Java dream job! Middle level Interview preparation"

I wish you a good luck in the course!

Yuval Ishay, Computrade
