package computrade.enumdemo;

public class myEnumClass {

}
