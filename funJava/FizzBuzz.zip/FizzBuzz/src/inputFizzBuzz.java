
public class inputFizzBuzz {
	public static void main(String[] args) {
		FizzBuzz iD = new FizzBuzz();
		
		String fizzBuzz = iD.fizzBuzz(2);
		System.out.println(fizzBuzz);
		
	}

}
