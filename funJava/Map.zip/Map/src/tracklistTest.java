import java.util.ArrayList;
import java.util.HashMap;

public class tracklistTest {
	public static void main (String[] args) {
		tracklist a = new tracklist();
		
//		titles: Perfect  , Havana  , Too good at goodbyes   ,  Thunder
		String str = a.track("Havana");
		System.out.println("************** \n This is the lyrics you Requested: \n" + str);
		
		
		
	}
	

}
