
public class Node {
	public int value;
	public Node next;
	public Node(int val) {
		this.value = val;
		this.next = null;
	}
	public void setValue(int value) {
		this.value = value;
	}
}

