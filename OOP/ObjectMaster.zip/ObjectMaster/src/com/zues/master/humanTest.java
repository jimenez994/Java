package com.zues.master;

public class humanTest {

	public static void main(String[] args) {
		human h = new human("Bod");
		human l = new human("Luke");
		h.attack(l);
		l.showHealth();
	

	}

}
