package com.zeus.zookeeeper;

public class GorillaTest {

	public static void main(String[] args) {
		Gorilla g = new Gorilla();
		g.throwSomething().throwSomething();
		g.climb();
		g.climb();
		g.eatBananas();
		g.displayEnergy();

	}

}
