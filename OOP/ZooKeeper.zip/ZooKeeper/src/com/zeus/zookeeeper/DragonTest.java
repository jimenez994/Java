package com.zeus.zookeeeper;

public class DragonTest {

	public static void main(String[] args) {
		Dragon d = new Dragon();
		d.dragon();
		d.attacktown().attacktown().attacktown().eatHumans().eatHumans().fly().fly();
		d.displayEnergy();

	}

}
