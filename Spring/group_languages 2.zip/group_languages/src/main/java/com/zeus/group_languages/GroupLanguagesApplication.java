package com.zeus.group_languages;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GroupLanguagesApplication {

	public static void main(String[] args) {
		SpringApplication.run(GroupLanguagesApplication.class, args);
	}
}
