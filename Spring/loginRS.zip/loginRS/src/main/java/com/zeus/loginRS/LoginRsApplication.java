package com.zeus.loginRS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginRsApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginRsApplication.class, args);
	}
}
