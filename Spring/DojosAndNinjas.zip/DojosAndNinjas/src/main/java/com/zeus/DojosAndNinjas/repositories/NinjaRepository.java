package com.zeus.DojosAndNinjas.repositories;



import org.springframework.data.repository.CrudRepository;

import com.zeus.DojosAndNinjas.models.Ninja;

public interface NinjaRepository extends CrudRepository<Ninja, Long>{

	
	
}
